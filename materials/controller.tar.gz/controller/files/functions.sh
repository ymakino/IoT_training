#!/bin/bash

function mosquitto_send() {
    if [ ! -z "$DEBUG" -a "$DEBUG" != "0" ]; then
        echo mosquitto_pub -t "$1" -m "$2"
    fi
    mosquitto_pub -t "$1" -m "$2"
}

function getT() {
    curl -s -XPOST -H "Content-Type: application/json" "http://localhost:9200/echomqtt-*/_search" -d @files/temperature.json | sed -e 's/^.*\({"avg".*[^}]}}\).*$/\1/' | sed -e 's/^.*"value":\([^}]*\).*$/\1/'
}

function getH() {
    curl -s -XPOST -H "Content-Type: application/json" "http://localhost:9200/echomqtt-*/_search" -d @files/humidity.json | sed -e 's/^.*\({"avg".*[^}]}}\).*$/\1/' | sed -e 's/^.*"value":\([^}]*\).*$/\1/'
}

function getAC() {
    lines=`curl -s -XPOST -H "Content-Type: application/json" "http://localhost:9200/echomqtt-*/_search?pretty" -d @files/ac.json  | egrep "operation_status|operation_mode|desired_temperature" | sed -e 's/$/\$/'`
    S=`echo $lines | tr '$' '\n' | grep operation_status | sed -e 's/.*://' -e 's/^[^"]*"\([^"]*\)"[^"]*$/\1/' | tail -n 1`
    M=`echo $lines | tr '$' '\n' | grep operation_mode | sed -e 's/.*://' -e 's/^[^"]*"\([^"]*\)"[^"]*$/\1/' | tail -n 1`
    T=`echo $lines | tr '$' '\n' | grep desired_temperature | sed -e 's/.*://' -e 's/^ *\([^, ]*\)[, ]*$/\1/' | tail -n 1`
    echo $S $M $T
}

function gt() {
    value=`python3 -c "print(0) if ($1 > $2) else print(1)"`
    return $value
}

function setLEDs() {
    R=$1
    G=$3
    B=$2
    mosquitto_send "control/lighting/029001/set" '{"lighting":"$R"}'
    mosquitto_send "control/lighting/029002/set" '{"lighting":"$B"}'
    mosquitto_send "control/lighting/029003/set" '{"lighting":"$G"}'
}

function setAC() {
    data=`printf '{"operation_status":"%s", "operation_mode":"%s", "desired_temperature":%0.1f}' $1 $2 $3`
    mosquitto_send "control/ac/013001/set" "${data}"

    if [ $1 == "OFF" ]; then
        setLEDs OFF OFF OFF
        return
    fi

    case $2 in
    AirConditioning)
        setLEDs OFF OFF ON;;
    Heating)
        setLEDs ON OFF OFF;;
    Dehumidify)
        setLEDs OFF ON OFF;;
    esac
}

