#!/bin/bash

DEBUG=0

. files/functions.sh

STATE=IDLE

while :; do

    T=`getT`
    H=`getH`
    AC=`getAC`

    printf "T: %0.1f, H: %0.1f, AC: %s\n" $T $H "$AC"

    . CONFIG.txt

    case $STATE in
    IDLE)
        if `gt $T $TC_1`; then NEXT_STATE=COOLING
        elif `gt $TH_1 $T`; then NEXT_STATE=HEATING
        elif `gt $H $HD_1`; then NEXT_STATE=DEHUMID
        fi;;
    COOLING)
        if `gt $TC_2 $T`; then NEXT_STATE=IDLE
        fi;;
    HEATING)
        if `gt $T $TH_2`; then NEXT_STATE=IDLE
        fi;;
    DEHUMID)
        if `gt $T $TC_1`; then NEXT_STATE=COOLING
        elif `gt $TH_1 $T`; then NEXT_STATE=HEATING
        elif `gt $HD_2 $H`; then NEXT_STATE=IDLE
        fi;;
    esac

    if [ $STATE == $NEXT_STATE ]; then
        echo "State: $STATE"
    else
        echo "State: $STATE -> $NEXT_STATE"
	STATE=$NEXT_STATE
    fi

    case $STATE in
    IDLE)
        setAC OFF Automatic $TI;;
    COOLING)
        setAC ON AirConditioning $TC;;
    HEATING)
        setAC ON Heating $TH;;
    DEHUMID)
        setAC ON Dehumidify $TD;;
    esac

    sleep 10
done
