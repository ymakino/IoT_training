#!/bin/bash

DEBUG=0

. files/functions.sh

STATE=IDLE
NEXT_STATE=$STATE

while :; do

    TEMP=`getTEMP`
    HUMID=`getHUMID`
    AC=`getAC`

    printf "TEMP: %0.1f, HUMID: %0.1f, AC: \"%s\"\n" $TEMP $HUMID "$AC"

    . CONFIG.txt

    #
    # Determine the next state transtion
    #
    case $STATE in
    IDLE)
        if `gt $TEMP $TEMP_COOLING_IN`; then NEXT_STATE=COOLING
        elif `gt $TEMP_HEATING_IN $TEMP`; then NEXT_STATE=HEATING
        elif `gt $HUMID $HUMID_DEHUMID_IN`; then NEXT_STATE=DEHUMID
        fi;;
    COOLING)
        if `gt $TEMP_COOLING_OUT $TEMP`; then NEXT_STATE=IDLE
        fi;;
    HEATING)
        if `gt $TEMP $TEMP_HEATING_OUT`; then NEXT_STATE=IDLE
        fi;;
    DEHUMID)
        if `gt $TEMP $TEMP_COOLING_IN`; then NEXT_STATE=COOLING
        elif `gt $TEMP_HEATING_IN $TEMP`; then NEXT_STATE=HEATING
        elif `gt $HUMID_DEHUMID_OUT $HUMID`; then NEXT_STATE=IDLE
        fi;;
    esac

    #
    # Show the state transition and execute it
    #
    if [ $STATE == $NEXT_STATE ]; then
        echo "State: $STATE"
    else
        echo "State: $STATE -> $NEXT_STATE"
        STATE=$NEXT_STATE
    fi

    #
    # Control the airconditioner and LEDs
    #
    case $STATE in
    IDLE)
        setAC OFF Automatic $TEMP_IDLE;;
    COOLING)
        setAC ON AirConditioning $TEMP_COOLING;;
    HEATING)
        setAC ON Heating $TEMP_HEATING;;
    DEHUMID)
        setAC ON Dehumidify $TEMP_DEHUMID;;
    esac

    #
    # Sleep until next interval
    #
    sleep $INTERVAL
done
