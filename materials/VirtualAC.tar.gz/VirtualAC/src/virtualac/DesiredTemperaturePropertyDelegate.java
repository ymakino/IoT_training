package virtualac;

import echowand.common.EPC;
import echowand.object.LocalObject;
import echowand.object.ObjectData;
import echowand.service.Core;
import echowand.service.PropertyDelegate;
import virtualac.ACModel.ACModelListener;

/**
 *
 * @author ymakino
 */
public class DesiredTemperaturePropertyDelegate extends PropertyDelegate {
    private ACModel acmodel;
    
    public DesiredTemperaturePropertyDelegate(EPC epc, boolean getEnabled, boolean setEnabled, boolean notifyEnabled) {
        super(epc, getEnabled, setEnabled, notifyEnabled);
    }
    
    @Override
    public void notifyCreation(LocalObject object, Core core) {
        acmodel = VirtualAC.getACModel();
        acmodel.setLocalObject(object);
    }
    
    @Override
    public ObjectData getUserData(LocalObject object, EPC epc) {
        return new ObjectData((byte)acmodel.getDesiredTemperature());
    }
    
    @Override
    public boolean setUserData(LocalObject object, EPC epc, ObjectData data) {
        if (data.size() != 1) {
            return false;
        }
        
        acmodel.setDesiredTemperature(data.get(0));
        
        return true;
    }
}
