package virtualac;

import javax.swing.UIManager;

/**
 *
 * @author ymakino
 */
public class VirtualAC {
    public static ControlPanel controlPanel = null;
    
    private static void updateLookAndFeel() {
        try {
            //UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            UIManager.setLookAndFeel("javax.swing.plaf.metal.MetalLookAndFeel");
            //com.sun.java.swing.plaf.gtk.GTKLookAndFeel
            //com.sun.java.swing.plaf.motif.MotifLookAndFeel
            //com.sun.java.swing.plaf.windows.WindowsLookAndFeel
        } catch (Exception e) {
                e.printStackTrace();
        }
    }
    
    public static ControlPanel getControlPanel() {
        if (controlPanel == null) {
            updateLookAndFeel();
            controlPanel = new ControlPanel();
            controlPanel.setVisible(true);
        }
        
        return controlPanel;
    }
    
    public static ACModel getACModel() {
        return getControlPanel().getModel();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        controlPanel = getControlPanel();
        controlPanel.getModel().start();
        controlPanel.setVisible(true);
    }
    
}
