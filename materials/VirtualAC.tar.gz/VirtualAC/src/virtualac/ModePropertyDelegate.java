package virtualac;

import echowand.common.EPC;
import echowand.object.LocalObject;
import echowand.object.ObjectData;
import echowand.service.Core;
import echowand.service.PropertyDelegate;
import virtualac.ACModel.ACModelListener;

/**
 *
 * @author ymakino
 */
public class ModePropertyDelegate extends PropertyDelegate {
    private ACModel acmodel;
    private ModeACModelListener listener;
    
    public class ModeACModelListener extends ACModelListener {
        
        public final ObjectData AutoData = new ObjectData((byte)0x41);
        public final ObjectData CoolerData = new ObjectData((byte)0x42);
        public final ObjectData HeaterData = new ObjectData((byte)0x43);
        
        @Override
        public void updateMode(ACModel.Mode mode) {
            switch (mode) {
                case Auto:
                    getLocalObject().notifyDataChanged(EPC.xB0, AutoData, CoolerData);
                    break;
                case Cooler:
                    getLocalObject().notifyDataChanged(EPC.xB0, CoolerData, HeaterData);
                    break;
                case Heater:
                    getLocalObject().notifyDataChanged(EPC.xB0, HeaterData, AutoData);
                    break;
            }
        }
    }
    
    public ModePropertyDelegate(EPC epc, boolean getEnabled, boolean setEnabled, boolean notifyEnabled) {
        super(epc, getEnabled, setEnabled, notifyEnabled);
    }
    
    @Override
    public void notifyCreation(LocalObject object, Core core) {
        acmodel = VirtualAC.getACModel();
        
        listener = new ModeACModelListener();
        acmodel.addListener(listener);
        
        acmodel.setLocalObject(object);
    }
    
    @Override
    public ObjectData getUserData(LocalObject object, EPC epc) {
        ObjectData data = null;
        
        switch (acmodel.getMode()) {
            case Auto:
                data = new ObjectData((byte)0x41);
                break;
            case Cooler:
                data = new ObjectData((byte)0x42);
                break;
            case Heater:
                data = new ObjectData((byte)0x43);
                break;
        }
        
        return data;
    }
    
    @Override
    public boolean setUserData(LocalObject object, EPC epc, ObjectData data) {
        if (data.size() != 1) {
            return false;
        }
        
        switch (data.get(0)) {
            case 0x41:
                acmodel.setMode(ACModel.Mode.Auto);
                return true;
            case 0x42:
                acmodel.setMode(ACModel.Mode.Cooler);
                return true;
            case 0x43:
                acmodel.setMode(ACModel.Mode.Heater);
                return true;
        }
        
        return false;
    }
}
