package virtualac;

import echowand.object.LocalObject;
import java.util.LinkedList;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author ymakino
 */
public class ACModel {
    public static enum Status { ON, OFF };
    public static enum Mode { Auto, Cooler, Heater, Dehumidify };
    public static enum Operation { Cooling, Heating, Dehumidify, Stopping };
    
    public static int DESIRED_TEMPERATURE_MIN = 10;
    public static int DESIRED_TEMPERATURE_MAX = 50;
    public static int AIRFLOW_MIN = 1;
    public static int AIRFLOW_MAX = 8;
    
    public Status status;
    public Mode mode;
    public Operation operation;
    public int desiredTemperature;
    public int airflow;
    public boolean autoAirflow;
    public LinkedList<ACModelListener> listeners = new LinkedList<>();
    
    public double temperatureValue = Double.NaN;
    public double humidityValue = Double.NaN;
    
    public LocalObject localObject;
    
    public static class ACModelListener {
        public synchronized void updateStatus(Status status) {}
        public synchronized void updateMode(Mode mode) {}
        public synchronized void updateOperation(Operation operation) {}
        public synchronized void updateDesiredTemperature(int desiredTemperature) {}
        public synchronized void updateAirflow(boolean autoAirflow, int airflow) {}
        public synchronized void updateTemperatureValue(double temperature) {}
        public synchronized void updateHumidityValue(double humidity) {}
    }
    
    public ACModel() {
        status = Status.OFF;
        mode = Mode.Auto;
        operation = Operation.Stopping;
        desiredTemperature = 28;
        airflow = 4;
        autoAirflow = false;
    }
    
    public void setLocalObject(LocalObject localObject) {
        this.localObject = localObject;
    }
    
    public void addListener(ACModelListener listener) {
        listeners.add(listener);
    }
    
    public boolean removeListener(ACModelListener listener) {
        return listeners.remove(listener);
    }
    
    public void setStatus(Status status) {
        this.status = status;
        
        for (ACModelListener listener : listeners) {
            listener.updateStatus(status);
        }
    }
    
    public Status getStatus() {
        return status;
    }
    
    public void setMode(Mode mode) {
        this.mode = mode;
        
        for (ACModelListener listener : listeners) {
            listener.updateMode(mode);
        }
    }
    
    public Mode getMode() {
        return mode;
    }
    
    public Operation getOperation() {
        return operation;
    }
    
    public void setDesiredTemperature(int temperature) {
        if (temperature < DESIRED_TEMPERATURE_MIN) {
            temperature = DESIRED_TEMPERATURE_MIN;
        }
        
        if (temperature > DESIRED_TEMPERATURE_MAX) {
            temperature = DESIRED_TEMPERATURE_MAX;
        }
        
        desiredTemperature = temperature;
        
        for (ACModelListener listener : listeners) {
            listener.updateDesiredTemperature(desiredTemperature);
        }
    }
    
    public int getDesiredTemperature() {
        return desiredTemperature;
    }
    
    public void setAirflow(int airflow) {
        if (airflow < AIRFLOW_MIN) {
            airflow = AIRFLOW_MIN;
        }
        
        if (airflow > AIRFLOW_MAX) {
            airflow = AIRFLOW_MAX;
        }
        
        this.airflow = airflow;
        for (ACModelListener listener : listeners) {
            listener.updateAirflow(autoAirflow, airflow);
        }
    }
    
    public int getAirflow() {
        return airflow;
    }
    
    public void setAirflowAuto(boolean auto) {
        autoAirflow = auto;
        for (ACModelListener listener : listeners) {
            listener.updateAirflow(autoAirflow, airflow);
        }
    }
    
    public boolean isAirflowAuto() {
        return autoAirflow;
    }
    
    public double getTemperatureValue() {
        return temperatureValue;
    }
    
    public void setTemperatureValue(double value) {
        temperatureValue = value;
        
        for (ACModelListener listener : listeners) {
            listener.updateTemperatureValue(temperatureValue);
        }
    }
    
    public double getHumidityValue() {
        return humidityValue;
    }
    
    public void setHumidityValue(double value) {
        humidityValue = value;
        
        for (ACModelListener listener : listeners) {
            listener.updateTemperatureValue(humidityValue);
        }
    }
    
    public Timer updateTimer;
    
    public void start() {
        updateTimer = new Timer();
        updateTimer.schedule(new OperationUpdateTask(),  1000, 500);
    }
    
    public void stop() {
        updateTimer.cancel();
        updateTimer = null;
    }
    
    public class OperationUpdateTask extends TimerTask {
        @Override
        public void run() {
            if (getStatus() == Status.OFF) {
                operation = Operation.Stopping;
            } else {
                switch (getMode()) {
                    case Auto:
                        if (getTemperatureValue() >= getDesiredTemperature()) {
                            operation = Operation.Cooling;
                        } else {
                            operation = Operation.Heating;
                        }
                        break;
                    case Cooler:
                        if (getTemperatureValue() >= getDesiredTemperature()) {
                            operation = Operation.Cooling;
                        } else {
                            operation = Operation.Stopping;
                        }
                        break;
                    case Heater:
                        if (getTemperatureValue() >= getDesiredTemperature()) {
                            operation = Operation.Stopping;
                        } else {
                            operation = Operation.Heating;
                        }
                        break;
                    case Dehumidify:
                        operation = Operation.Dehumidify;
                        break;
                }
            }
            
            for (ACModelListener listener : listeners) {
                listener.updateOperation(operation);
            }
        }
    }
}
