package virtualac;

import echowand.common.EPC;
import echowand.object.LocalObject;
import echowand.object.ObjectData;
import echowand.service.Core;
import echowand.service.PropertyDelegate;
import virtualac.ACModel.ACModelListener;

/**
 *
 * @author ymakino
 */
public class AirflowPropertyDelegate extends PropertyDelegate {
    private ACModel acmodel;
    private AirflowACModelListener listener;
    
    public class AirflowACModelListener extends ACModelListener {
        ObjectData autoData = new ObjectData((byte)0x41);
        
        @Override
        public void updateAirflow(boolean autoAirflow, int airflow) {
            if (autoAirflow) {
                getLocalObject().notifyDataChanged(EPC.xA0, autoData, new ObjectData((byte)0x00));
            } else {
                ObjectData airflowData = new ObjectData((byte)(0x30 + airflow));
                getLocalObject().notifyDataChanged(EPC.xA0, airflowData, autoData);
            }
        }
    }
    
    public AirflowPropertyDelegate(EPC epc, boolean getEnabled, boolean setEnabled, boolean notifyEnabled) {
        super(epc, getEnabled, setEnabled, notifyEnabled);
    }
    
    @Override
    public void notifyCreation(LocalObject object, Core core) {
        acmodel = VirtualAC.getACModel();
        
        listener = new AirflowACModelListener();
        acmodel.addListener(listener);
        
        acmodel.setLocalObject(object);
    }
    
    @Override
    public ObjectData getUserData(LocalObject object, EPC epc) {
        ObjectData data = null;
        
        if (acmodel.isAirflowAuto()) {
            data = new ObjectData((byte)0x41);
        } else {
            data = new ObjectData((byte)(acmodel.getAirflow() + 0x30));
            
        }
        
        return data;
    }
    
    @Override
    public boolean setUserData(LocalObject object, EPC epc, ObjectData data) {
        if (data.size() != 1) {
            return false;
        }
        
        if (data.get(0) == 0x41) {
            acmodel.setAirflowAuto(true);
        } else {
            acmodel.setAirflowAuto(false);
            acmodel.setAirflow(data.get(0) - 0x30);
        }
        
        return false;
    }
}
