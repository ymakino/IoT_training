package virtualac;

import virtualac.ACModel.ACModelListener;

/**
 *
 * @author ymakino
 */
public class ControlPanel extends javax.swing.JFrame {
    public static String ON = "ON";
    public static String OFF = "OFF";
    public static String HEATING = "暖房中";
    public static String COOLING = "冷房中";
    public static String DEHUMIDIFY = "除湿中";
    public static String STOPPING = "停止中";
    
    public class ControlPanelListener extends ACModelListener {
        
        @Override
        public void updateStatus(ACModel.Status status) {
            ControlPanel.this.updateStatus();
        }
        
        @Override
        public void updateMode(ACModel.Mode mode) {
            ControlPanel.this.updateMode();
        }
        
        @Override
        public void updateOperation(ACModel.Operation operation) {
            ControlPanel.this.updateOperation();
        }
        
        @Override
        public void updateDesiredTemperature(int desiredTemperature) {
            ControlPanel.this.updateDesiredTemperature();
        }
        
        @Override
        public void updateAirflow(boolean autoAirflow, int airflow) {
            ControlPanel.this.updateAirflow();
        }
        
        @Override
        public void updateTemperatureValue(double temperature) {
            ControlPanel.this.updateSensorText();
        }
        
        @Override
        public void updateHumidityValue(double humidity) {
            ControlPanel.this.updateSensorText();
        }
    }
    
    public ACModel acmodel;

    /**
     * Creates new form ControlPanel
     */
    public ControlPanel() {
        acmodel = new ACModel();
        acmodel.addListener(new ControlPanelListener());
        initComponents();
    }
    
    public ACModel getModel() {
        return acmodel;
    }
    
    public void updateStatus() {
        switch (acmodel.getStatus()) {
            case ON:
                statusButton.setText(ON);
                break;
            case OFF:
                statusButton.setText(OFF);
                break;
        }
    }
    
    public void updateMode() {
        switch (acmodel.getMode()) {
            case Auto:
                if (!modeAutoButton.isSelected()) {
                    modeAutoButton.setSelected(true);
                }
                break;
            case Cooler:
                if (!modeCoolerButton.isSelected()) {
                    modeCoolerButton.setSelected(true);
                }
                break;
            case Heater:
                if (!modeHeaterButton.isSelected()) {
                    modeHeaterButton.setSelected(true);
                }
                break;
            case Dehumidify:
                if (!modeDehumidifyButton.isSelected()) {
                    modeDehumidifyButton.setSelected(true);
                }
        }
    }
    
    public void updateOperation() {
        switch (acmodel.getOperation()) {
            case Cooling:
                operationLabel.setText(COOLING);
                break;
            case Heating:
                operationLabel.setText(HEATING);
                break;
            case Dehumidify:
                operationLabel.setText(DEHUMIDIFY);
                break;
            case Stopping:
                operationLabel.setText(STOPPING);
                break;
        }
    }
    
    public void updateDesiredTemperature() {
        int desiredTemperature = acmodel.getDesiredTemperature();
        if (desiredTemperatureSlider.getModel().getValue() != desiredTemperature) {
            desiredTemperatureSlider.getModel().setValue(desiredTemperature);
        }
        
        if (!desiredTemperatureComboBox.getModel().getSelectedItem().equals(Integer.toString(desiredTemperature))) {
            desiredTemperatureComboBox.getModel().setSelectedItem(Integer.toString(desiredTemperature));
        }
    }
        
    public void updateAirflow() {
        boolean autoAirflow = acmodel.isAirflowAuto();
        int airflow = acmodel.getAirflow();
                
        if (airflowAutoCheckBox.isSelected() != autoAirflow) {
            airflowAutoCheckBox.setSelected(autoAirflow);
            airflowComboBox.setEnabled(!autoAirflow);
        } 

        int oldAirflow = Integer.decode((String)airflowComboBox.getSelectedItem());
        if (oldAirflow != airflow) {
            airflowComboBox.getModel().setSelectedItem(Integer.toString(airflow));
        }
    }
    
    public void updateSensorText() {
        Double temperature = acmodel.getTemperatureValue();
        String temperatureText = String.format("%d", temperature.intValue());
        temperatureLabel.setText(temperatureText);

        Double humidity = acmodel.getHumidityValue();
        String humidityText = String.format("%d", humidity.intValue());
        humidityLabel.setText(humidityText);
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        buttonGroup1 = new javax.swing.ButtonGroup();
        jPanel8 = new javax.swing.JPanel();
        statusButton = new javax.swing.JToggleButton();
        modePanel = new javax.swing.JPanel();
        modeAutoButton = new javax.swing.JRadioButton();
        modeCoolerButton = new javax.swing.JRadioButton();
        modeHeaterButton = new javax.swing.JRadioButton();
        modeDehumidifyButton = new javax.swing.JRadioButton();
        desiredTemperaturePanel = new javax.swing.JPanel();
        desiredTemperatureSlider = new javax.swing.JSlider();
        desiredTemperatureComboBox = new javax.swing.JComboBox<>();
        airflowPanel = new javax.swing.JPanel();
        airflowAutoCheckBox = new javax.swing.JCheckBox();
        airflowComboBox = new javax.swing.JComboBox<>();
        sensorPanel = new javax.swing.JPanel();
        sensorTemperatureOuterPanel = new javax.swing.JPanel();
        sensorTemperatureInnerPanel = new javax.swing.JPanel();
        temperatureTitleLabel = new javax.swing.JLabel();
        temperatureLabel = new javax.swing.JLabel();
        temperatureUnitLabel = new javax.swing.JLabel();
        sensorHumidityOuterPanel = new javax.swing.JPanel();
        sensorHumidityInnerPanel = new javax.swing.JPanel();
        humidityTitleLabel = new javax.swing.JLabel();
        humidityLabel = new javax.swing.JLabel();
        humidityUnitLabel = new javax.swing.JLabel();
        operationIndicatorPanel = new javax.swing.JPanel();
        operationLabel = new javax.swing.JLabel();

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 100, Short.MAX_VALUE)
        );

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("仮想エアコン");
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowActivated(java.awt.event.WindowEvent evt) {
                formWindowActivated(evt);
            }
        });

        statusButton.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        statusButton.setText("OFF");
        statusButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ToggleStatusPerformed(evt);
            }
        });

        modePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "運転モード", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        modePanel.setName(""); // NOI18N

        buttonGroup1.add(modeAutoButton);
        modeAutoButton.setSelected(true);
        modeAutoButton.setText("自動");
        modeAutoButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeAutoButtonActionPerformed(evt);
            }
        });
        modePanel.add(modeAutoButton);

        buttonGroup1.add(modeCoolerButton);
        modeCoolerButton.setText("冷房");
        modeCoolerButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeCoolerButtonActionPerformed(evt);
            }
        });
        modePanel.add(modeCoolerButton);

        buttonGroup1.add(modeHeaterButton);
        modeHeaterButton.setText("暖房");
        modeHeaterButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeHeaterButtonActionPerformed(evt);
            }
        });
        modePanel.add(modeHeaterButton);

        buttonGroup1.add(modeDehumidifyButton);
        modeDehumidifyButton.setText("除湿");
        modeDehumidifyButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                modeDehumidifyButtonActionPerformed(evt);
            }
        });
        modePanel.add(modeDehumidifyButton);

        desiredTemperaturePanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "温度設定値", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        desiredTemperatureSlider.setMaximum(50);
        desiredTemperatureSlider.setMinimum(10);
        desiredTemperatureSlider.setValue(28);
        desiredTemperatureSlider.addChangeListener(new javax.swing.event.ChangeListener() {
            public void stateChanged(javax.swing.event.ChangeEvent evt) {
                changeDesiredTemperature(evt);
            }
        });
        desiredTemperaturePanel.add(desiredTemperatureSlider);

        desiredTemperatureComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "10", "11", "12", "13", "14", "15", "16", "17", "18", "19", "20", "21", "22", "23", "24", "25", "26", "27", "28", "29", "30", "31", "32", "33", "34", "35", "36", "37", "38", "39", "40", "41", "42", "43", "44", "45", "46", "47", "48", "49", "50" }));
        desiredTemperatureComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                selectTemperature(evt);
            }
        });
        desiredTemperaturePanel.add(desiredTemperatureComboBox);

        airflowPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "風量設定", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));

        airflowAutoCheckBox.setText("自動");
        airflowAutoCheckBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                airflowAutoCheckBoxActionPerformed(evt);
            }
        });
        airflowPanel.add(airflowAutoCheckBox);

        airflowComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "1", "2", "3", "4", "5", "6", "7", "8" }));
        airflowComboBox.setSelectedIndex(3);
        airflowComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateAirflow(evt);
            }
        });
        airflowPanel.add(airflowComboBox);

        sensorPanel.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "センサ計測値", javax.swing.border.TitledBorder.CENTER, javax.swing.border.TitledBorder.DEFAULT_POSITION));
        sensorPanel.setLayout(new java.awt.GridLayout(1, 0));

        sensorTemperatureInnerPanel.setLayout(new java.awt.BorderLayout());

        temperatureTitleLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        temperatureTitleLabel.setText("温度:");
        sensorTemperatureInnerPanel.add(temperatureTitleLabel, java.awt.BorderLayout.WEST);

        temperatureLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        temperatureLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        temperatureLabel.setText("--");
        sensorTemperatureInnerPanel.add(temperatureLabel, java.awt.BorderLayout.CENTER);

        temperatureUnitLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        temperatureUnitLabel.setText("℃");
        sensorTemperatureInnerPanel.add(temperatureUnitLabel, java.awt.BorderLayout.EAST);

        sensorTemperatureOuterPanel.add(sensorTemperatureInnerPanel);

        sensorPanel.add(sensorTemperatureOuterPanel);

        sensorHumidityInnerPanel.setLayout(new java.awt.BorderLayout());

        humidityTitleLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        humidityTitleLabel.setText("湿度:");
        sensorHumidityInnerPanel.add(humidityTitleLabel, java.awt.BorderLayout.WEST);

        humidityLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        humidityLabel.setHorizontalAlignment(javax.swing.SwingConstants.RIGHT);
        humidityLabel.setText("--");
        sensorHumidityInnerPanel.add(humidityLabel, java.awt.BorderLayout.CENTER);

        humidityUnitLabel.setFont(new java.awt.Font("Lucida Grande", 0, 18)); // NOI18N
        humidityUnitLabel.setText("%");
        sensorHumidityInnerPanel.add(humidityUnitLabel, java.awt.BorderLayout.EAST);

        sensorHumidityOuterPanel.add(sensorHumidityInnerPanel);

        sensorPanel.add(sensorHumidityOuterPanel);

        operationIndicatorPanel.setLayout(new java.awt.BorderLayout());

        operationLabel.setFont(new java.awt.Font("Lucida Grande", 0, 24)); // NOI18N
        operationLabel.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        operationLabel.setText("停止中");
        operationIndicatorPanel.add(operationLabel, java.awt.BorderLayout.CENTER);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(statusButton, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(operationIndicatorPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(modePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(desiredTemperaturePanel, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(airflowPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(sensorPanel, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 342, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );

        layout.linkSize(javax.swing.SwingConstants.HORIZONTAL, new java.awt.Component[] {airflowPanel, desiredTemperaturePanel, modePanel, sensorPanel});

        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap(21, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(modePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(desiredTemperaturePanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(statusButton, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(airflowPanel, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(sensorPanel, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(operationIndicatorPanel, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        layout.linkSize(javax.swing.SwingConstants.VERTICAL, new java.awt.Component[] {airflowPanel, desiredTemperaturePanel, modePanel, sensorPanel});

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void selectTemperature(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_selectTemperature
        // TODO add your handling code here:
        String desiredTemperature = (String)(desiredTemperatureComboBox.getModel().getSelectedItem());
        if (!desiredTemperature.equals(desiredTemperatureSlider.getModel().getValue())) {
            desiredTemperatureSlider.getModel().setValue(Integer.decode(desiredTemperature));
        }
    }//GEN-LAST:event_selectTemperature

    private void updateAirflow(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateAirflow
        // TODO add your handling code here:
        String airflow = (String)(airflowComboBox.getModel().getSelectedItem());
        acmodel.setAirflow(Integer.decode(airflow));
    }//GEN-LAST:event_updateAirflow

    private void ToggleStatusPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ToggleStatusPerformed
        // TODO add your handling code here:
        if (statusButton.getModel().isSelected()) {
            acmodel.setStatus(ACModel.Status.ON);
        } else {
            acmodel.setStatus(ACModel.Status.OFF);
        }
    }//GEN-LAST:event_ToggleStatusPerformed

    private void changeDesiredTemperature(javax.swing.event.ChangeEvent evt) {//GEN-FIRST:event_changeDesiredTemperature
        // TODO add your handling code here:
        int desiredTemperature = desiredTemperatureSlider.getModel().getValue();
        desiredTemperatureComboBox.getModel().setSelectedItem(Integer.toString(desiredTemperature));
        acmodel.setDesiredTemperature(desiredTemperature);
    }//GEN-LAST:event_changeDesiredTemperature

    private void airflowAutoCheckBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_airflowAutoCheckBoxActionPerformed
        // TODO add your handling code here:
        if (airflowAutoCheckBox.getModel().isSelected()) {
            airflowComboBox.setEnabled(false);
            acmodel.setAirflowAuto(true);
        } else {
            airflowComboBox.setEnabled(true);
            acmodel.setAirflowAuto(false);
        }
    }//GEN-LAST:event_airflowAutoCheckBoxActionPerformed

    private void modeAutoButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeAutoButtonActionPerformed
        // TODO add your handling code here:
        acmodel.setMode(ACModel.Mode.Auto);
    }//GEN-LAST:event_modeAutoButtonActionPerformed

    private void modeCoolerButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeCoolerButtonActionPerformed
        // TODO add your handling code here:
        acmodel.setMode(ACModel.Mode.Cooler);
    }//GEN-LAST:event_modeCoolerButtonActionPerformed

    private void modeHeaterButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeHeaterButtonActionPerformed
        // TODO add your handling code here:
        acmodel.setMode(ACModel.Mode.Heater);
    }//GEN-LAST:event_modeHeaterButtonActionPerformed

    private void formWindowActivated(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowActivated
        // TODO add your handling code here:
        this.updateStatus();
        this.updateMode();
        this.updateOperation();
        this.updateDesiredTemperature();
        this.updateAirflow();
        this.updateSensorText();
        
        acmodel.start();
    }//GEN-LAST:event_formWindowActivated

    private void modeDehumidifyButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_modeDehumidifyButtonActionPerformed
        // TODO add your handling code here:
        acmodel.setMode(ACModel.Mode.Dehumidify);
    }//GEN-LAST:event_modeDehumidifyButtonActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ControlPanel.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ControlPanel().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JCheckBox airflowAutoCheckBox;
    private javax.swing.JComboBox<String> airflowComboBox;
    private javax.swing.JPanel airflowPanel;
    private javax.swing.ButtonGroup buttonGroup1;
    private javax.swing.JComboBox<String> desiredTemperatureComboBox;
    private javax.swing.JPanel desiredTemperaturePanel;
    private javax.swing.JSlider desiredTemperatureSlider;
    private javax.swing.JLabel humidityLabel;
    private javax.swing.JLabel humidityTitleLabel;
    private javax.swing.JLabel humidityUnitLabel;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JRadioButton modeAutoButton;
    private javax.swing.JRadioButton modeCoolerButton;
    private javax.swing.JRadioButton modeDehumidifyButton;
    private javax.swing.JRadioButton modeHeaterButton;
    private javax.swing.JPanel modePanel;
    private javax.swing.JPanel operationIndicatorPanel;
    private javax.swing.JLabel operationLabel;
    private javax.swing.JPanel sensorHumidityInnerPanel;
    private javax.swing.JPanel sensorHumidityOuterPanel;
    private javax.swing.JPanel sensorPanel;
    private javax.swing.JPanel sensorTemperatureInnerPanel;
    private javax.swing.JPanel sensorTemperatureOuterPanel;
    private javax.swing.JToggleButton statusButton;
    private javax.swing.JLabel temperatureLabel;
    private javax.swing.JLabel temperatureTitleLabel;
    private javax.swing.JLabel temperatureUnitLabel;
    // End of variables declaration//GEN-END:variables
}
