package virtualac;

import echowand.common.EOJ;
import echowand.common.EPC;
import echowand.object.LocalObject;
import echowand.object.ObjectData;
import echowand.service.Core;
import echowand.service.PropertyDelegate;
import java.util.HashMap;
import java.util.Timer;
import java.util.TimerTask;

/**
 *
 * @author ymakino
 */
public class TemperaturePropertyDelegate extends PropertyDelegate {
    private ACModel acmodel;
    private EOJ eoj = new EOJ("001101");
    private Timer updateTimer;
    
    public TemperaturePropertyDelegate(EPC epc, boolean getEnabled, boolean setEnabled, boolean notifyEnabled, HashMap<String, String> params) {
        super(epc, getEnabled, setEnabled, notifyEnabled);
        
        if (params.containsKey("eoj")) {
            eoj = new EOJ(params.get("eoj"));
        }
        
        updateTimer = new Timer();
    }
    
    public class UpdateTimerTask extends TimerTask {
        @Override
        public void run() {
            updateTemperature();
        }
    }
    
    public void setEOJ(String eoj) {
        this.eoj = new EOJ(eoj);
    }
    
    public Double updateTemperature() {
        LocalObject localObject;
        
        synchronized(getCore().getMainLoop()) {
            localObject = getCore().getLocalObjectManager().get(eoj);
        }
        
        if (localObject == null) {
            return null;
        }
        
        ObjectData data = localObject.getData(EPC.xE0);
        
        if (data.size() != 2) {
            return null;
        }
        
        int d0 = data.get(0);
        int d1 = data.get(1);
        
        double temperature = ((d0 << 8) | (0x00ff & d1)) / 10.0;
        acmodel.setTemperatureValue(Math.round(temperature));
        
        return temperature;
    }
    
    @Override
    public void notifyCreation(LocalObject object, Core core) {
        acmodel = VirtualAC.getACModel();
        updateTimer.schedule(new UpdateTimerTask(), 1000, 5000);
    }
    
    @Override
    public ObjectData getUserData(LocalObject object, EPC epc) {
        Double temperature = acmodel.getTemperatureValue();
        return new ObjectData((byte)((double)temperature));
    }
}
