package virtualac;

import echowand.common.EPC;
import echowand.object.LocalObject;
import echowand.object.ObjectData;
import echowand.service.Core;
import echowand.service.PropertyDelegate;
import virtualac.ACModel.ACModelListener;

/**
 *
 * @author ymakino
 */
public class StatusPropertyDelegate extends PropertyDelegate {
    private ACModel acmodel;
    private StatusACModelListener listener;
    
    public class StatusACModelListener extends ACModelListener {
        
        public final ObjectData OnData = new ObjectData((byte)0x30);
        public final ObjectData OffData = new ObjectData((byte)0x31);
        
        @Override
        public void updateStatus(ACModel.Status status) {
            switch (status) {
                case ON:
                    getLocalObject().notifyDataChanged(EPC.x80, OnData, OffData);
                    break;
                case OFF:
                    getLocalObject().notifyDataChanged(EPC.x80, OffData, OnData);
                    break;
            }
        }
    }
    
    public StatusPropertyDelegate(EPC epc, boolean getEnabled, boolean setEnabled, boolean notifyEnabled) {
        super(epc, getEnabled, setEnabled, notifyEnabled);
    }
    
    @Override
    public void notifyCreation(LocalObject object, Core core) {
        acmodel = VirtualAC.getACModel();
        
        listener = new StatusACModelListener();
        acmodel.addListener(listener);
        
        acmodel.setLocalObject(object);
    }
    
    @Override
    public ObjectData getUserData(LocalObject object, EPC epc) {
        ObjectData data = null;
        
        switch (acmodel.getStatus()) {
            case ON:
                data = new ObjectData((byte)0x30);
                break;
            case OFF:
                data = new ObjectData((byte)0x31);
                break;
        }
        
        return data;
    }
    
    @Override
    public boolean setUserData(LocalObject object, EPC epc, ObjectData data) {
        if (data.size() != 1) {
            return false;
        }
        
        switch (data.get(0)) {
            case 0x30:
                acmodel.setStatus(ACModel.Status.ON);
                return true;
            case 0x31:
                acmodel.setStatus(ACModel.Status.OFF);
                return true;
        }
        
        return false;
    }
}
